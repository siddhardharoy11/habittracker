const Habit = require('../models/Habit');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

// @desc    Get all habits for logged in user
// @route   GET /api/v1/habits
// @access  Private
exports.getHabits = asyncHandler(async (req, res, next) => {
  const habits = await Habit.find({ user: req.user.id });

  res.status(200).json({
    success: true,
    count: habits.length,
    data: habits
  });
});

// @desc    Get single habit
// @route   GET /api/v1/habits/:id
// @access  Private
exports.getHabit = asyncHandler(async (req, res, next) => {
  const habit = await Habit.findOne({
    _id: req.params.id,
    user: req.user.id
  });

  if (!habit) {
    return next(
      new ErrorResponse(`Habit not found with id of ${req.params.id}`, 404)
    );
  }

  res.status(200).json({
    success: true,
    data: habit
  });
});

// @desc    Create new habit
// @route   POST /api/v1/habits
// @access  Private
exports.createHabit = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.user = req.user.id;

  const habit = await Habit.create(req.body);

  res.status(201).json({
    success: true,
    data: habit
  });
});

// @desc    Update habit
// @route   PUT /api/v1/habits/:id
// @access  Private
exports.updateHabit = asyncHandler(async (req, res, next) => {
  let habit = await Habit.findById(req.params.id);

  if (!habit) {
    return next(
      new ErrorResponse(`Habit not found with id of ${req.params.id}`, 404)
    );
  }

  // Make sure user owns the habit
  if (habit.user.toString() !== req.user.id) {
    return next(
      new ErrorResponse(
        `User ${req.user.id} is not authorized to update this habit`,
        401
      )
    );
  }

  habit = await Habit.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: habit
  });
});

// @desc    Delete habit
// @route   DELETE /api/v1/habits/:id
// @access  Private
exports.deleteHabit = asyncHandler(async (req, res, next) => {
  const habit = await Habit.findById(req.params.id);

  if (!habit) {
    return next(
      new ErrorResponse(`Habit not found with id of ${req.params.id}`, 404)
    );
  }

  // Make sure user owns the habit
  if (habit.user.toString() !== req.user.id) {
    return next(
      new ErrorResponse(
        `User ${req.user.id} is not authorized to delete this habit`,
        401
      )
    );
  }

  await habit.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Track habit completion
// @route   POST /api/v1/habits/:id/track
// @access  Private
exports.trackHabit = asyncHandler(async (req, res, next) => {
  const { date, completed } = req.body;

  if (!date) {
    return next(new ErrorResponse('Please provide a date', 400));
  }

  const habit = await Habit.findOne({
    _id: req.params.id,
    user: req.user.id
  });

  if (!habit) {
    return next(
      new ErrorResponse(`Habit not found with id of ${req.params.id}`, 404)
    );
  }

  // Normalize dates to compare only year, month, and day
  const trackingDate = new Date(date);
  trackingDate.setHours(0, 0, 0, 0);

  // Check if tracking entry already exists for this date
  const existingEntryIndex = habit.tracking.findIndex(entry => {
    const entryDate = new Date(entry.date);
    entryDate.setHours(0, 0, 0, 0);
    return entryDate.getTime() === trackingDate.getTime();
  });

  if (existingEntryIndex >= 0) {
    // Update existing entry
    habit.tracking[existingEntryIndex].completed = completed;
  } else {
    // Add new entry
    habit.tracking.push({ date: trackingDate, completed });
  }

  await habit.save();

  res.status(200).json({
    success: true,
    data: habit
  });
});