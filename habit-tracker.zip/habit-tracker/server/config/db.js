const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    if (!process.env.MONGO_URI) {
      throw new Error('MONGO_URI is not defined in environment variables');
    }

    // Remove all deprecated options
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 5000,
      maxPoolSize: 10,
      socketTimeoutMS: 30000
    });

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
    return conn;
  } catch (err) {
    console.error('❌ Database connection error:', err.message);
    
    // Specific error handling
    if (err.message.includes('bad auth')) {
      console.error('Authentication failed. Please check:');
      console.error('1. Your MongoDB Atlas username/password');
      console.error('2. That your IP is whitelisted in Atlas');
      console.error('3. The database user has correct privileges');
    }
    
    process.exit(1);
  }
};

// Improved connection event handling
mongoose.connection.on('connected', () => {
  console.log('🔗 Mongoose connected to DB');
});

mongoose.connection.on('disconnected', () => {
  console.log('⚠️ Mongoose disconnected - attempting to reconnect...');
  setTimeout(connectDB, 5000);
});

process.on('SIGINT', async () => {
  await mongoose.connection.close();
  console.log('🚪 Mongoose connection closed due to app termination');
  process.exit(0);
});

module.exports = connectDB;