const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  createHabit,
  getHabits,
  updateHabit,
  deleteHabit
} = require('../controllers/habitController');

// Apply protect middleware to all habit routes
router.use(protect);

router.route('/')
  .post(createHabit)
  .get(getHabits);

router.route('/:id')
  .put(updateHabit)
  .delete(deleteHabit);

module.exports = router;