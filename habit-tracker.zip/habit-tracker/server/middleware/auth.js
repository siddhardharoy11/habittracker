const jwt = require('jsonwebtoken');
const ErrorResponse = require('../utils/errorResponse');
const User = require('../models/User');

exports.protect = async (req, res, next) => {
  let token;
  
  // 1. Check Authorization header
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  } 
  // 2. Check cookies (if using)
  else if (req.cookies?.token) {
    token = req.cookies.token;
  }

  // If no token found
  if (!token) {
    console.error('No token provided in request');
    return next(new ErrorResponse('Not authorized to access this route', 401));
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Get user and attach to request
    req.user = await User.findById(decoded.id).select('-password');
    
    if (!req.user) {
      console.error('User not found for token');
      return next(new ErrorResponse('User not found', 401));
    }
    
    next();
  } catch (err) {
    console.error('Token verification failed:', err.message);
    return next(new ErrorResponse('Not authorized to access this route', 401));
  }
};